package com.cohs.pojo;

public class Room {
	private int roomNo;
	private int roomRent;
	public Room(int roomNo, int roomRent) {
		super();
		this.roomNo = roomNo;
		this.roomRent = roomRent;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public int getRoomRent() {
		return roomRent;
	}
	public void setRoomRent(int roomRent) {
		this.roomRent = roomRent;
	}
	
}
